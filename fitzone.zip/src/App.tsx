import { 
  Dumbbell, 
  Play, 
  UserCheck, 
  ClipboardList, 
  Users, 
  Flame, 
  Activity, 
  Flower2, 
  ArrowRight,
  MapPin,
  Phone,
  Mail,
  Clock,
  Menu,
  Star
} from 'lucide-react';

function Navbar() {
  return (
    <nav className="flex items-center justify-between px-6 lg:px-16 py-6 border-b border-white/5">
      <div className="flex items-center gap-3">
        <Dumbbell className="text-yellow-500 w-8 h-8" />
        <div className="flex flex-col">
          <span className="font-black text-2xl leading-none tracking-wider">LIFE FITNESS</span>
          <span className="text-[10px] tracking-[0.2em] text-gray-400 font-bold mt-0.5">STRONGER EVERYDAY</span>
        </div>
      </div>
      <div className="hidden lg:flex items-center gap-8 text-xs font-bold tracking-widest">
        <a href="#" className="text-yellow-500">HOME</a>
        <a href="#" className="text-white hover:text-yellow-500 transition-colors">GALLERY</a>
        <a href="#" className="text-white hover:text-yellow-500 transition-colors">CLASSES</a>
        <a href="#" className="text-white hover:text-yellow-500 transition-colors">CONTACT</a>
      </div>
      <button className="hidden lg:block bg-yellow-500 text-black px-6 py-2.5 font-bold text-sm rounded hover:bg-yellow-400 transition-colors tracking-wide">
        JOIN NOW
      </button>
      <button className="lg:hidden text-white">
        <Menu className="w-6 h-6" />
      </button>
    </nav>
  );
}

function Hero() {
  return (
    <section className="relative px-6 lg:px-16 py-20 lg:py-32 overflow-hidden">
      <div className="max-w-7xl mx-auto relative z-10 grid lg:grid-cols-2 gap-12">
        <div className="flex flex-col justify-center">
          <h2 className="text-lg lg:text-xl text-gray-200 font-bold uppercase tracking-widest mb-4">
            Build strength.<br/>Build confidence.
          </h2>
          <h1 className="text-6xl lg:text-[5.5rem] font-black uppercase leading-[1.05] mb-6 tracking-wide">
            Become<br />
            <span className="text-yellow-500">Your Best</span>
          </h1>
          <p className="text-gray-400 text-base max-w-md mb-10 leading-relaxed">
            Join a community that pushes you, supports you and helps you become the strongest version of yourself.
          </p>
          <div className="flex flex-wrap items-center gap-6">
            <button className="bg-yellow-500 text-black px-8 py-3.5 font-bold rounded flex items-center gap-2 hover:bg-yellow-400 transition-colors text-sm tracking-wide">
              JOIN NOW <ArrowRight className="w-4 h-4" />
            </button>
            <button className="flex items-center gap-3 text-white hover:text-yellow-500 transition-colors font-bold text-sm tracking-wider group">
              <div className="w-12 h-12 rounded-full border-2 border-gray-600 flex items-center justify-center group-hover:border-yellow-500 transition-colors">
                <Play className="w-4 h-4 fill-current ml-1" />
              </div>
              WATCH VIDEO
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

function Features() {
  const features = [
    { icon: Dumbbell, title: 'MODERN EQUIPMENT', desc: 'Top quality machines and equipments for effective workouts.' },
    { icon: UserCheck, title: 'EXPERT TRAINERS', desc: 'Certified & experienced trainers to guide you every step.' },
    { icon: ClipboardList, title: 'PERSONALIZED PLANS', desc: 'Workout and diet plans tailored to your goals and lifestyle.' },
    { icon: Users, title: 'SUPPORTIVE COMMUNITY', desc: 'A positive environment that keeps you motivated and consistent.' }
  ];

  return (
    <section className="px-6 lg:px-16 -mt-8 relative z-20">
      <div className="max-w-7xl mx-auto bg-[#111] border border-white/5 rounded-2xl p-8 lg:p-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 divide-y md:divide-y-0 md:divide-x divide-white/10">
          {features.map((feat, idx) => (
            <div key={idx} className={`flex gap-5 ${idx !== 0 ? 'md:pl-8 pt-8 md:pt-0' : ''}`}>
              <feat.icon className="w-10 h-10 text-yellow-500 shrink-0" strokeWidth={1.5} />
              <div>
                <h3 className="font-bold text-white mb-2 text-sm tracking-wide uppercase">{feat.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{feat.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Programs() {
  const programs = [
    { img: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=500&auto=format&fit=crop', icon: Dumbbell, title: 'STRENGTH TRAINING', desc: 'Build lean muscle and increase overall strength.' },
    { img: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=500&auto=format&fit=crop', icon: Flame, title: 'WEIGHT LOSS', desc: 'Effective fat loss programs for a healthier you.' },
    { img: 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=500&auto=format&fit=crop', icon: Activity, title: 'FUNCTIONAL TRAINING', desc: 'Improve mobility, endurance and everyday performance.' },
    { img: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=500&auto=format&fit=crop', icon: Flower2, title: 'YOGA & WELLNESS', desc: 'Balance your body and mind with yoga and stretching.' }
  ];

  return (
    <section className="px-6 lg:px-16 py-24">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-yellow-500 font-bold tracking-widest text-sm uppercase">OUR PROGRAMS</span>
          <h2 className="text-4xl lg:text-5xl font-black text-white mt-4 uppercase tracking-wide">
            Train. Focus. Achieve.
          </h2>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {programs.map((prog, idx) => (
            <div key={idx} className="bg-[#111] rounded-xl overflow-hidden border border-white/5 group hover:border-yellow-500/30 transition-colors">
              <div className="h-56 overflow-hidden">
                <img src={prog.img} alt={prog.title} className="w-full h-full object-cover grayscale opacity-60 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-500" />
              </div>
              <div className="p-8">
                <prog.icon className="w-8 h-8 text-yellow-500 mb-5" strokeWidth={1.5} />
                <h3 className="font-bold text-white text-lg mb-3 tracking-wide uppercase">{prog.title}</h3>
                <p className="text-gray-400 text-sm mb-8 leading-relaxed">
                  {prog.desc}
                </p>
                <a href="#" className="text-yellow-500 font-bold text-sm flex items-center gap-2 hover:gap-3 transition-all uppercase tracking-wide">
                  LEARN MORE <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section className="px-6 lg:px-16 py-20 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
        <div className="relative">
          <h3 className="text-3xl lg:text-4xl text-center font-black text-white mb-8 uppercase tracking-wide">Our Gallery</h3>
          <div className="grid grid-cols-2 gap-4 pb-6">
            <div className="aspect-square rounded-xl overflow-hidden border border-white/5">
              <img src="https://images.unsplash.com/photo-1576678927484-cc907957088c?w=800&auto=format&fit=crop" alt="Gym" className="w-full h-full object-cover grayscale opacity-80 hover:grayscale-0 transition-all duration-500" />
            </div>
            <div className="aspect-square rounded-xl overflow-hidden border border-white/5 translate-y-6">
              <img src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&auto=format&fit=crop" alt="Gym Workout" className="w-full h-full object-cover grayscale opacity-80 hover:grayscale-0 transition-all duration-500" />
            </div>
            <div className="aspect-square rounded-xl overflow-hidden border border-white/5">
              <img src="https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=800&auto=format&fit=crop" alt="Gym Equipment" className="w-full h-full object-cover grayscale opacity-80 hover:grayscale-0 transition-all duration-500" />
            </div>
            <div className="aspect-square rounded-xl overflow-hidden border border-white/5 translate-y-6">
              <img src="https://images.unsplash.com/photo-1518611012118-696072aa579a?w=800&auto=format&fit=crop" alt="Fitness" className="w-full h-full object-cover grayscale opacity-80 hover:grayscale-0 transition-all duration-500" />
            </div>
          </div>
        </div>
        <div>
          <span className="text-yellow-500 font-bold tracking-widest text-sm uppercase">ABOUT US</span>
          <h2 className="text-4xl lg:text-5xl font-black text-white mt-4 mb-6 uppercase leading-[1.1] tracking-wide">
            More than a gym,<br/>we are a community.
          </h2>
          <p className="text-gray-400 text-base leading-relaxed mb-8 max-w-lg">
            At Life Fitness, we believe that true transformation starts from within. Our expert coaches and supportive community are dedicated to helping you push past your limits and build a stronger, healthier version of yourself.
            <br/><br/>
            Whether you're taking your very first step or striving for a new personal best, we provide the tools, guidance, and motivation you need to succeed every single day.
          </p>
          <button className="bg-yellow-500 text-black px-8 py-3.5 font-bold rounded flex items-center gap-2 hover:bg-yellow-400 transition-colors text-sm tracking-wide">
            JOIN OUR COMMUNITY <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  const footerInfo = [
    { icon: MapPin, title: 'ADDRESS', desc: '5th Floor, Life Fitness Pro Sidhivinayak Business Hub,\nCircle, nr. Ghevar Complex, Arihant Nagar, Shahibag,\nAhmedabad, Gujarat 380016' },
    { icon: Phone, title: 'PHONE', desc: '09157098443' },
    { icon: Mail, title: 'EMAIL', desc: 'hello@lifefitness.com' },
    { icon: Clock, title: 'OPENING HOURS', desc: 'Mon - Sat: 6:00 AM – 10:00 PM\nSunday: 7:00 AM – 12:00 PM' }
  ];

  return (
    <footer className="bg-black py-16 px-6 lg:px-16 border-t border-white/5">
      <div className="max-w-7xl mx-auto grid md:grid-cols-2 lg:grid-cols-4 gap-12">
        {footerInfo.map((info, idx) => (
          <div key={idx} className="flex gap-4">
            <info.icon className="w-6 h-6 text-yellow-500 shrink-0 mt-0.5" strokeWidth={1.5} />
            <div>
              <h4 className="font-bold text-white text-sm tracking-widest mb-2 uppercase">{info.title}</h4>
              <p className="text-gray-400 text-sm leading-relaxed whitespace-pre-line">{info.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </footer>
  );
}

function Reviews() {
  const reviews = [
    {
      name: "Rahul Desai",
      rating: 5,
      date: "2 months ago",
      text: "Best gym in Shahibaug area! The equipment is top-notch, especially the Life Fitness Pro2 series. Spacious and very well maintained.",
    },
    {
      name: "Sneha Patel",
      rating: 5,
      date: "3 weeks ago",
      text: "The trainers are extremely knowledgeable and supportive. They actually pay attention to your form. Highly recommend for beginners!",
    },
    {
      name: "Amit Shah",
      rating: 4,
      date: "1 month ago",
      text: "Great atmosphere and a positive vibe. It gets a bit crowded in the evenings, but the management is friendly and cooperative.",
    },
    {
      name: "Priya Sharma",
      rating: 5,
      date: "4 months ago",
      text: "I love the variety of machines they have. Clean changing rooms and the membership pricing is totally worth the facilities provided.",
    }
  ];

  return (
    <section className="px-6 lg:px-16 py-20 border-t border-white/5 bg-[#111]">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <span className="text-yellow-500 font-bold tracking-widest text-sm uppercase">TESTIMONIALS</span>
            <h2 className="text-4xl lg:text-5xl font-black text-white mt-4 uppercase tracking-wide">
              Rating & Reviews
            </h2>
          </div>
          <div className="flex flex-col items-start md:items-end">
            <div className="flex items-center gap-4 mb-2">
              <span className="text-6xl font-black text-white leading-none">4.7</span>
              <div className="flex flex-col gap-1">
                <div className="flex gap-1 text-yellow-500">
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current opacity-50" />
                </div>
                <span className="text-sm font-bold text-gray-400 tracking-wide uppercase">2,033 Reviews</span>
              </div>
            </div>
            <a href="https://maps.app.goo.gl/vdGGMMM4GxaPW33L6" target="_blank" rel="noreferrer" className="text-yellow-500 font-bold text-xs tracking-widest uppercase hover:text-yellow-400 transition-colors flex items-center gap-2 mt-2">
              READ ALL REVIEWS <ArrowRight className="w-3 h-3" />
            </a>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviews.map((rev, idx) => (
            <div key={idx} className="bg-[#0a0a0a] p-8 rounded-xl border border-white/5 hover:border-yellow-500/30 transition-colors flex flex-col h-full group">
              <div className="flex gap-1 text-yellow-500 mb-6">
                {[...Array(rev.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
                {[...Array(5 - rev.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-gray-700" />
                ))}
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-8 flex-grow">"{rev.text}"</p>
              <div className="mt-auto flex justify-between items-end border-t border-white/5 pt-4">
                <div>
                  <h4 className="font-bold text-white tracking-wide uppercase text-sm mb-1">{rev.name}</h4>
                  <span className="text-xs font-bold tracking-widest text-gray-500 uppercase">{rev.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function LocationMap() {
  return (
    <section className="px-6 lg:px-16 py-20 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-yellow-500 font-bold tracking-widest text-lg lg:text-xl uppercase">LOCATION</span>
          <h2 className="text-3xl lg:text-4xl font-black text-white mt-4 uppercase tracking-wide">
            Find Us Here
          </h2>
        </div>
        <div className="w-full h-[450px] rounded-xl overflow-hidden border border-white/5">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3671.1021962124482!2d72.599141!3d23.0567146!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e85edadbc8bed%3A0xc96b5e7a1ff0540!2sLife%20Fitness%20Pro!5e0!3m2!1sen!2sin!4v1786960098824!5m2!1sen!2sin" 
            width="100%" 
            height="100%" 
            style={{ border: 0 }} 
            allowFullScreen={false} 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-yellow-500 selection:text-black">
      <Navbar />
      <Hero />
      <Features />
      <Programs />
      <About />
      <Reviews />
      <LocationMap />
      <Footer />
    </div>
  );
}
